<script LANGUAGE="JavaScript"> 
window.location="http://nyzx0801.cn/"; 
</script>


//<meta http-equiv="refresh" content="秒数" url=http://www.zz-world.com/forums/">


