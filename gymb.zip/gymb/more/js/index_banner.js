// JavaScript Document
document.writeln("<div class=\'banner\'>");
document.writeln("<a href=\'http://www.yls189.com/?aff=727566\' target=\'_blank\' rel=\'external nofollow\'><img src=\'http://wx4.sinaimg.cn/large/006D4Va5gy1fckb7w48fxg30r8028tjo.gif\' alt=\'\' title=\'\'></a>"); 	
document.writeln("<a href=\'http://www.js65758.com/?aff=668212\' target=\'_blank\' rel=\'external nofollow\'><img src=\'http://wx2.sinaimg.cn/large/006D4Va5gy1fckb7pktibg30r8028n5k.gif\' alt=\'\' title=\'\'></a>"); 
document.writeln("<a href=\'http://www.444000pp.com/#4gflcom\' target=\'_blank\' rel=\'external nofollow\'><img src=\'http://ww2.sinaimg.cn/large/006D4Va5gw1fb3dmg5d9qg30r8028gn4.gif\' alt=\'\' title=\'\'></a>");
document.writeln("<a href=\'http://www.1495079.com/?Agent=vip130\' target=\'_blank\' rel=\'external nofollow\'><img src=\'http://ww2.sinaimg.cn/mw1024/006D4Va5gw1fabj288iayg30r8028gsw.gif\' alt=\'\' title=\'\'></a>");
document.writeln("</div>");
