function password() {
var testV = 1;
var pass1 = prompt('         本网页属于私人（天生傲骨）制作 \n                   (你有三次机会)\n    网页已加密，输入正确密码才能进入哦!  \n   密码请联系—天生傲骨QQ:2987981960\n','天生傲骨QQ:2987981960');
while (testV < 3) {
if (!pass1) 
history.go(-1);
if (pass1 == "研若") {
alert('             成功\n\n     成功检测！你可以进入！\n           请浏览！……！！\n');
break;
} 
testV+=1;
var pass1 = 
prompt('             失败\n\n     检测失败！你是谁？傻逼吗！\n      进入请联系—天生傲骨QQ:2987981960获取密码\n');
}
if (pass1!="password" & testV ==3)               
history.go(-1);
return " ";
}						
document.write(password());
