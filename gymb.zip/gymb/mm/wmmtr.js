function password() {
var testV = 1;
var pass1 = prompt('         本网页属于私人制作 \n                   (你有三次机会)\n    网页已加密，输入正确密码才能进入哦!  \n   心中那无法忘记的誓言，群号码：599169571获取密码…\n','群号码:599169571');
while (testV < 3) {
if (!pass1) 
history.go(-1);
if (pass1 == "他人") {
alert('             成功\n\n     成功检测！是自己人！\n           请浏览！……！！\n');
break;
} 
testV+=1;
var pass1 = 
prompt('             失败\n\n     检测失败！你是谁？傻逼吗！\n      获取暗号请请加群…\n');
}
if (pass1!="password" & testV ==3)               
history.go(-1);
return " ";
}						
document.write(password());
