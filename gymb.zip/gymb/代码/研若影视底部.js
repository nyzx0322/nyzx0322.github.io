本站提供的最新电影和电视剧资源均系收集于各大视频网站,本站只提供web页面服务,并不提供影片资源存储,也不参与录制、上传<br />
若本站收录的节目无意侵犯了贵司版权，请给网页底部邮箱地址来信,我们会及时处理和回复,谢谢。<br />
管理员邮箱：2987981960@qq.com <br />
购买本站程序可联系QQ：2987981960<br>

<iframe height="24" src="http://www.123456dj.com/skins/123456dj/bfq/kc/" frameborder="110" width="100%" style="width:450px;height:37px;"></iframe>
<br>




<center>今天是:<span><script language=Javascript type=text/Javascript> 
var day=""; 
var month=""; 
var ampm=""; 
var ampmhour=""; 
var myweekday=""; 
var year=""; 
mydate=new Date(); 
myweekday=mydate.getDay(); 
mymonth=mydate.getMonth()+1; 
myday= mydate.getDate(); 
myyear= mydate.getYear(); 
year=(myyear > 200) ? myyear : 1900 + myyear; 
if(myweekday == 0) 
weekday=" 星期日 "; 
else if(myweekday == 1) 
weekday=" 星期一 "; 
else if(myweekday == 2) 
weekday=" 星期二 "; 
else if(myweekday == 3) 
weekday=" 星期三 "; 
else if(myweekday == 4) 
weekday=" 星期四 "; 
else if(myweekday == 5) 
weekday=" 星期五 "; 
else if(myweekday == 6) 
weekday=" 星期六 "; 
document.write(year+"年"+mymonth+"月"+myday+"日 "+weekday); 
</script><br><b><FONT COLOR="#FF0000">本站已经安全运行:</FONT></b> 
<span id="span_dt_dt"></span> 
<SCRIPT language=javascript> 
<!-- 
//document.write(""); 
function show_date_time(){ 
window.setTimeout("show_date_time()", 1000); 
BirthDay=new Date("06-03-2018 19:00:00");//建站日期 
today=new Date(); 
timeold=(today.getTime()-BirthDay.getTime()); 
sectimeold=timeold/1000 
secondsold=Math.floor(sectimeold); 
msPerDay=24*60*60*1000 
e_daysold=timeold/msPerDay 
daysold=Math.floor(e_daysold); 
e_hrsold=(daysold-e_daysold)*-24; 
hrsold=Math.floor(e_hrsold); 
e_minsold=(hrsold-e_hrsold)*-60; 
minsold=Math.floor((hrsold-e_hrsold)*-60); 
seconds=Math.floor((minsold-e_minsold)*-60); 
span_dt_dt.innerHTML=daysold+"天"+hrsold+"小时"+minsold+"分"+seconds+"秒" ; 
} 
show_date_time(); 
//--> 
</SCRIPT>
<br><br><br><br>

<div style="display:none;">
<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?1b228034eab3f86498adfd4e9d337209";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script>
</div>             